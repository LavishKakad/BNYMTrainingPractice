package com.interfaces;

public interface I2 {
	void m2();
}
